package com.services;
import java.util.*;
import com.beans.Customer;

public class CustomerServiceImpl implements CustomerService{
	ArrayList<Customer> arr= new ArrayList<Customer>();
	public void addCustomer(Customer customer) {
		arr.add(customer);
	}
	public void displayCustomers() {
		Iterator<Customer> itr= arr.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
	}
	public void searchCustomer(int customerId) {
		for (Customer s : arr) {
			if(s.getCustomerId()==customerId) {
				System.out.println(s);
				break;
			}
		}
	}
	public void deleteCustomer(int customerId) {
		for (Customer s : arr) {
			if(s.getCustomerId()==customerId) {
				arr.remove(s);
				System.out.println("Customer deleted successfully with customer id = "+customerId);
				break;
			}
		}
	}

}
