package com.exceptions;

public class CustomerException extends Exception {
	String msg;
	public CustomerException(String msg){
		this.msg=msg;
	}
	
	public String toString() {
		return this.msg;
	}

}
