package com.exceptions;

public class ContactException extends Exception{
	String msg;
	public ContactException(String msg){
		this.msg=msg;
	}
	
	public String toString() {
		return this.msg;
	}

}
