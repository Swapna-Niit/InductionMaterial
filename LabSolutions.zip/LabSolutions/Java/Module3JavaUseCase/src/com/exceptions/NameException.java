package com.exceptions;

public class NameException extends Exception{
	String msg;
	public NameException(String msg){
		this.msg=msg;
	}
	
	public String toString() {
		return this.msg;
	}

}
