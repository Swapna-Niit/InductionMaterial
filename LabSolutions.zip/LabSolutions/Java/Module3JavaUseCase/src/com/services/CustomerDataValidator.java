package com.services;

import com.exceptions.*;

public class CustomerDataValidator {
	
	public static boolean nameValidator(String name) throws CustomerException {
		String namePattern="^[A-Za-z]+$";
		if(name.matches(namePattern)) {
			return true;
		}
		else {
			throw new CustomerException("Name can only have alphabets");
		}
	}
	public static boolean contactValidator(String contact) throws CustomerException {
		String contactPattern="^[7-9][0-9]{9}$";
		if(contact.matches(contactPattern)) {
			return true;
		}
		else {
			throw new CustomerException("Contact no can only have 10 digits");
		}
	}
	public static boolean emailValidator(String email) throws CustomerException {
		String contactPattern="^[a-zA-z0-9]+@[A-za-z]+$";
		if(email.matches(contactPattern)) {
			return true;
		}
		else {
			throw new CustomerException("E-mailid is invalid");
		}
	}
	public static boolean accountTypeValidator(String accountType) throws CustomerException
	{
		if(accountType.equalsIgnoreCase("Savings") ||accountType.equalsIgnoreCase("Current"))
		{
			return true;
		}
		else
		{
			throw new CustomerException("Account Type can be only Savings/Current");
		}
	}

}
