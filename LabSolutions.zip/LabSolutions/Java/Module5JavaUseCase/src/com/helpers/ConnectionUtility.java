package com.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtility {

	private final static String url = "jdbc:postgresql://localhost:5432/topgun";
	private final static String username = "postgres";
	private final static String password = "admin";
	static Connection con = null;
	public static Connection getConnection() {			
		try {
			// load the driver
			Class.forName("org.postgresql.Driver");
			// create the connection
			con = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}

}
