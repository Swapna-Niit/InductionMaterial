package com.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import com.beans.Customer;
import com.helpers.ConnectionUtility;

public class CustomerServiceImpl implements CustomerService {

	Connection con;

	public void addCustomer(Customer customer) {

		try {
			con = ConnectionUtility.getConnection();
			String sql = "insert into customers values(?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, customer.getCustomerId());
			pstmt.setString(2, customer.getName());
			pstmt.setString(3, customer.getContact());
			pstmt.setString(4, customer.getEmail());
			pstmt.setString(5, customer.getAccountType());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public List<Customer> displayCustomers() {
		ArrayList<Customer> arr = new ArrayList<Customer>();
		con = ConnectionUtility.getConnection();
		String sql = "select cust_id,cust_name,cust_phone,cust_email,cust_account_type from customers";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setContact(rs.getString(3));
				customer.setEmail(rs.getString(4));
				customer.setAccountType(rs.getString(5));
				arr.add(customer);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arr;

	}

	public Customer searchCustomer(int customerId) {
		Customer customer = null;
		con = ConnectionUtility.getConnection();
		String sql = "select  cust_id,cust_name,cust_phone,cust_email,cust_account_type from customers where cust_id=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, customerId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				customer = new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setContact(rs.getString(3));
				customer.setEmail(rs.getString(4));
				customer.setAccountType(rs.getString(5));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}

	public void deleteCustomer(int customerId) {
		try {
			con = ConnectionUtility.getConnection();
			String sql = "delete from customers where cust_id=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, customerId);
			int count = pstmt.executeUpdate();
			if (count == 1)
				System.out.println("Customer deleted successfully with customer id = " + customerId);
			else
				System.out.println("Customer does not exist for deletion");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
