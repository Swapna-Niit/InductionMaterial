package com.ui;
import java.util.Scanner;
import com.controller.*;
import com.helpers.ConnectionUtility;
public class CustomerUI {

	public static void main(String args[]) {
		Scanner scr = new Scanner(System.in);
		CustomerController test= new CustomerController();
		while (true) {
			System.out
					.println("Welcome to Standard Chartered Bank"
							+ "\nPlease enter your choice"
							+ "\n1 for Add new Customer "
							+ "\n2 for Display Customers"
							+ "\n3 for Search Customer"
							+ "\n4 for Delete Customer"
							+ "\n5 for Exit the bank application");
			int option = scr.nextInt();

			switch (option) {

			case 1:
				test.addCustomer();
				break;
			case 2:
				test.displayCustomers();
				break;
			case 3:
				test.searchCustomer(scr);
				break;	
			case 4:
				test.deleteCustomer(scr);
				break;	
			case 5:
				System.exit(0);

			}

		}
	}

}
