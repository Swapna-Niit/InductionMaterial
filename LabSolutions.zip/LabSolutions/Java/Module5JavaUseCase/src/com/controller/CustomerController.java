package com.controller;

import java.util.*;
import com.beans.*;
import com.exceptions.*;
import com.helpers.*;
import com.services.CustomerDataValidator;
import com.services.CustomerServiceImpl;

public class CustomerController {
	CustomerServiceImpl service = new CustomerServiceImpl();
	Scanner scr = new Scanner(System.in);

	public void addCustomer() {

		System.out.println("Please enter customer details :");
		System.out.println("Enter name :");
		String name = scr.next();
		try {
			if (CustomerDataValidator.nameValidator(name)) {
				System.out.println("Enter email :");
				String email = scr.next();
				if (CustomerDataValidator.emailValidator(email)) {
					System.out.println("Enter contact :");
					String contact = scr.next();
					if (CustomerDataValidator.contactValidator(contact)) {
						System.out.println("Enter account type (Savings or Current):");
						String accountType = scr.next();
						if (CustomerDataValidator.accountTypeValidator(accountType)) {
							int customerId = Helper.generateCustomerId();
							System.out.println("Customer added suucessfully with customer id " + customerId);
							Customer customer = new Customer();
							customer.setCustomerId(customerId);
							customer.setName(name);
							customer.setEmail(email);
							customer.setContact(contact);
							customer.setAccountType(accountType);
							service.addCustomer(customer);
						}
					}
				}

			}
		} catch (CustomerException exception) {
			System.out.println(exception);
		}

	}

	public void displayCustomers() {
		List<Customer> arr=service.displayCustomers();
		Iterator<Customer> itr= arr.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

	public void searchCustomer(Scanner scr) {
		System.out.println("Please enter customer id");
		int customerId = scr.nextInt();
		Customer customer=service.searchCustomer(customerId);
		if(customer!=null)
			System.out.println(customer);
		else
			System.out.println("Customer does not exist");

	}

	public void deleteCustomer(Scanner scr) {
		System.out.println("Please enter customer id to be deleted");
		int customerId = scr.nextInt();
		service.deleteCustomer(customerId);

	}

}
