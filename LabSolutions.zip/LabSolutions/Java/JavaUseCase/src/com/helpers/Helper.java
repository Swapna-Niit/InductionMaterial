package com.helpers;

import java.util.Random;

public class Helper {
	public static int generateCustomerId() 
	{
		Random random = new Random();
		char[] digit = new char[4];
		for(int i=0;i<4;i++)
		{
			digit[i] = (char) (Math.abs(random.nextInt(9)+'0'));
		}
		int customerId = Integer.parseInt(new String(digit));
		return customerId;
	}

}
