package com.beans;

public class Customer {

	private int customerId;
	private String name;
	private String email;
	private String contact;
	private String accountType;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String toString() {
		return "Customer Id = " + this.customerId + ", Customer name = " + this.name + ", Customer email = " + this.email
				+ ", Customer contact = " + this.contact + ", Customer account type = " + this.accountType;
	}

}
