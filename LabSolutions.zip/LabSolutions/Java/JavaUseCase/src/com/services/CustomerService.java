package com.services;

import java.util.Scanner;

import com.beans.Customer;

public interface CustomerService {
	
	public void addCustomer(Customer customer);
	public void displayCustomers();
	public void searchCustomer(int customerId);
	public void deleteCustomer(int customerId);

}
