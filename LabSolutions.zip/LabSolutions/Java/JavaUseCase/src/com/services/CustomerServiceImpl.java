package com.services;

import com.beans.Customer;

public class CustomerServiceImpl implements CustomerService{
	Customer[] arr= new Customer[20];
	public void addCustomer(Customer customer) {
		boolean flag=false;
		for(int i=0;i<arr.length;i++) {
			flag=true;
			if(arr[i]==null) {
				arr[i]=customer;
				break;
			}
		}
		if(!flag)
			arr[0]=customer;
	}
	public void displayCustomers() {
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==null) {
				break;
			}
			System.out.println(arr[i]);
		}
	}
	public void searchCustomer(int customerId) {
		for (Customer s : arr) {
			if(s.getCustomerId()==customerId) {
				System.out.println(s);
				break;
			}
		}
	}
	public void deleteCustomer(int customerId) {
		for (int i=0;i<arr.length;i++) {
			if(arr[i].getCustomerId()==customerId) {
				for (int j=i;j<arr.length;j++) {
					Customer temp= arr[i+1];
					arr[i]=temp;
				}
				System.out.println("Deleted customer with id ="+customerId);
				break;
			}
		}
	}

}
