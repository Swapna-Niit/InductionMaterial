import React from "react";

class Alert extends React.Component {
  showAlert() {
    alert("React is a great ui library");
  }

  render() {
    return (
    <div>
      <button onClick={this.showAlert}>
        Show alert
      </button>
    </div>
    )
  }
}

export default Alert;
