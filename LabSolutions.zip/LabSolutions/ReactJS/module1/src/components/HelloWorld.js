import React from "react";

class HelloWorld extends React.Component {
  render() {
    return <div>Hello World Component</div>;
  }
}

export default HelloWorld;