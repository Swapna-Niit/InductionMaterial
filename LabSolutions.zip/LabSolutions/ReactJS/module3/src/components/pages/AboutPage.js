import React, { Component } from "react";

class AboutPage extends Component {
  render() {
    return (
      <div className="jumbotron blue-bg">
        <h1>Tech Behind TopGun Bank</h1>
        <hr />
        <p>It is built with the most modern technologies and provides the best user experience ever</p>
        <ul>
          <li>React V0.16, React-Router, </li>
          <li>ES6 JavaScript and Bootstrap 3.x for styling</li>
          <li>Java 8, Spring Boot 2.x and REST APIs in the Backend</li>
        </ul>
      </div>
    );
  }
}

export default AboutPage;
