import React from "react";
import axios from "axios";
import AccountsList from "../accounts/AccountsList";
import { Link } from "react-router-dom";

export class CustomerDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      customer: null
    };
  }

  componentDidMount = () => {
    const custId = this.props.match.params.id;
    axios
      .get("http://localhost:8080/api/customers/" + custId)
      .then(res => {
        this.setState({
          customer: res.data
        });
      })
      .catch(err => {
        console.log(err);
      });
  };

  getCustDetailsDiv() {
    const { customer } = this.state;
    const backLinkText = "< Back to Customers List";

    return (
      <div>
        <div className="row">
          <Link color="primary" to="/customers">
            {backLinkText}
          </Link>
        </div>
        <hr />
        <div className="row">
          <div className="col-md-4">
            <h4>Customer Details</h4>
            <hr />
            <p>ID : {customer.id} </p>
            <p>First Name : {customer.firstName} </p>
            <p>Last Name: {customer.lastName} </p>
            <p>Email: {customer.email} </p>
            <p>Phone: {customer.phone} </p>
          </div>
          <div className="col-md-8">
            <AccountsList customerId={customer.id} />
          </div>
        </div>
      </div>
    );
  }

  render() {
    return <div>{this.state.customer ? this.getCustDetailsDiv() : null}</div>;
  }
}

export default CustomerDetails;
