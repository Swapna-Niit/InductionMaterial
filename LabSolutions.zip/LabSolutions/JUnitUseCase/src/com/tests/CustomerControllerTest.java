package com.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.beans.Customer;
import com.controller.CustomerController;
import com.services.CustomerServiceImpl;

class CustomerControllerTest {

	@Test
	void test() {		
		Customer cust= new Customer();
		cust.setName("Sandra");
		cust.setContact("9999999999");
		cust.setEmail("abc@gmail");
		cust.setAccountType("savings");
		assertEquals("Sanndra",cust.getName());
		assertNotNull(cust);
	}

}
