package com.tests;

import org.junit.jupiter.api.Test;

import com.exceptions.CustomerException;
import com.services.CustomerDataValidator;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerValidatorTest {
	@Test
	public void nameValidatorTest() throws CustomerException {
		String name="sandra";
		boolean flag=CustomerDataValidator.nameValidator(name);
		assertTrue(flag);
	}
	@Test
	public void phoneValidatorTest() throws CustomerException {
		String contact="9988998878";
		boolean flag=CustomerDataValidator.contactValidator(contact);
		assertTrue(flag);
	}
	@Test
	public void accountTypeValidatorTest() throws CustomerException {
		String accountType="savings";
		boolean flag=CustomerDataValidator.accountTypeValidator(accountType);
		assertTrue(flag);
	}
	@Test
	public void emailValidatorTest() throws CustomerException {
		String email="abc@gmail";
		boolean flag=CustomerDataValidator.emailValidator(email);
		assertTrue(flag);
	}

}
