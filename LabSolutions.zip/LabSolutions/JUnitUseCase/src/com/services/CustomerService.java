package com.services;

import java.util.List;
import java.util.Scanner;

import com.beans.Customer;

public interface CustomerService {
	
	public int addCustomer(Customer customer);
	public List<Customer> displayCustomers();
	public Customer searchCustomer(int customerId);
	public void deleteCustomer(int customerId);

}
