package com.pck;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class JacksonTester {
	public static void main(String args[]) {
		Scanner scr = new Scanner(System.in);

		while (true) {
			System.out
					.println("Please enter the options"
							+ "\n1 Add new Customer in JSON file "
							+ "\n2 Display JSON data"
							+ "\n3 Exit");
			int option = scr.nextInt();

			switch (option) {

			case 1:
				addCustomers(scr);
				break;
			case 2:
				displayCustomers();
				break;
			case 3:
				System.exit(0);

			}

		}
	}



	private static void addCustomers(Scanner scr) {
		try {
			System.out.println("How many customers you want to create :");
			int count = scr.nextInt();
			Customer[] arr = new Customer[count];

			for (int i = 0; i < count; i++) {
				System.out.println("Please enter customer details :");
				System.out.println("Enter first name :");
				String fname = scr.next();
				System.out.println("Enter second name :");
				String lname = scr.next();
				Customer customer = new Customer();
				customer.setFirstName(fname);
				customer.setLastName(lname);
				arr[i] = customer;
			}

			writeJSON(arr);

			

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	private static void displayCustomers() {
		try{
			
			Customer[] custArr = readJSON();
			for (Customer s : custArr)
				System.out.println(s);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static void writeJSON(Customer[] customer)
			throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(new File("customer.json"), customer);
	}

	private static Customer[] readJSON() throws JsonParseException,
			JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		Customer[] customer = mapper.readValue(new File("customer.json"),
				Customer[].class);
		return customer;
	}
}

class Customer {
	private String firstName;
	private String lastName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString(){
		return "First Name = "+ this.firstName+", Last Name = "+this.lastName;
		}

}
